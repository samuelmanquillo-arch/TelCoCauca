#ifndef CLIENTENODO_H
#define CLIENTENODO_H

#include <string>

class ClienteNodo {
private:
    std::string idNodo;
    std::string tipoSensor;
    double valorBase;
    int puertoTCP;
    int puertoUDP;
    bool sensorDanado;
public:
    ClienteNodo(const std::string& _idNodo, const std::string& _tipoSensor, double _valorBase,
                int _puertoTCP, int _puertoUDP, bool _sensorDanado);

    void ejecutar(int& completados);
};

#endif
