#include "Trama.h"
#include "ExcepcionNodoRed.h"
#include <map>
#include <sstream>

Trama::Trama(const std::string& _idNodo, const std::string& _tipoSensor, double _valor)
    : idNodo(_idNodo), tipoSensor(_tipoSensor), valor(_valor) {}

std::string Trama::getIdNodo() const { return idNodo; }
std::string Trama::getTipoSensor() const { return tipoSensor; }
double Trama::getValor() const { return valor; }

std::string Trama::serializar() const {
    std::ostringstream salida;
    salida << "NODO=" << idNodo << ";SENSOR=" << tipoSensor << ";VALOR=" << valor;
    return salida.str();
}

std::string Trama::descripcion() const {
    std::ostringstream salida;
    salida << idNodo << " -> " << tipoSensor << " = " << valor;
    return salida.str();
}

Trama Trama::deserializar(const std::string& texto) {
    std::map<std::string, std::string> campos;
    std::istringstream entrada(texto);
    std::string pedazo;
    while (std::getline(entrada, pedazo, ';')) {
        std::size_t igual = pedazo.find('=');
        if (igual == std::string::npos) {
            throw ExcepcionNodoRed(201, "Trama invalida, falta el signo '=' en: " + pedazo);
        }
        campos[pedazo.substr(0, igual)] = pedazo.substr(igual + 1);
    }

    if (campos.count("NODO") == 0 || campos.count("SENSOR") == 0 || campos.count("VALOR") == 0) {
        throw ExcepcionNodoRed(201, "Trama invalida, faltan campos: " + texto);
    }

    double valorLeido = 0.0;
    try {
        valorLeido = std::stod(campos["VALOR"]);
    }
    catch (const std::exception&) {
        throw ExcepcionNodoRed(201, "Trama invalida, el valor no es numerico: " + campos["VALOR"]);
    }

    if (valorLeido < -40.0 || valorLeido > 120.0) {
        throw ExcepcionNodoRed(202, "Valor fuera de rango en la trama de " + campos["NODO"] + ": " + campos["VALOR"]);
    }
    return Trama(campos["NODO"], campos["SENSOR"], valorLeido);
}
