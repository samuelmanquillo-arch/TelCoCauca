#ifndef EXCEPCIONNODORED_H
#define EXCEPCIONNODORED_H

#include <stdexcept>
#include <string>

class ExcepcionNodoRed : public std::runtime_error {
private:
    int codigo;
public:
    ExcepcionNodoRed(int _codigo, const std::string& mensaje);
    int getCodigo() const;
};

#endif
