#ifndef SENSORIOT_H
#define SENSORIOT_H

#include <string>

class SensorIoT {
private:
    std::string tipoSensor;
    double valorLectura;
    std::string unidad;
public:
    SensorIoT(const std::string& _tipoSensor, double _valorLectura, const std::string& _unidad);

    std::string getTipoSensor() const;
    double getValorLectura() const;
    std::string getUnidad() const;

    void setValorLectura(double _valorLectura);
};

#endif
