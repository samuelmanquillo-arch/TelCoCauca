#include "SensorIoT.h"

SensorIoT::SensorIoT(const std::string& _tipoSensor, double _valorLectura, const std::string& _unidad)
    : tipoSensor(_tipoSensor), valorLectura(_valorLectura), unidad(_unidad) {}

std::string SensorIoT::getTipoSensor() const { return tipoSensor; }
double SensorIoT::getValorLectura() const { return valorLectura; }
std::string SensorIoT::getUnidad() const { return unidad; }

void SensorIoT::setValorLectura(double _valorLectura) { valorLectura = _valorLectura; }
