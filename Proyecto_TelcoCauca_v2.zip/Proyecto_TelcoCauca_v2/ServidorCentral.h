#ifndef SERVIDORCENTRAL_H
#define SERVIDORCENTRAL_H

#include <string>
#include <vector>
#include "RedCompat.h"
#include "Trama.h"

class ServidorCentral {
private:
    int puertoTCP;
    int puertoUDP;
    TipoSocket socketTCP;
    TipoSocket socketUDP;
    int tramasValidas;
    int tramasRechazadas;
    std::vector<Trama> bufferLecturas;

    void guardarLectura(const Trama& trama, const std::string& origen);
public:
    ServidorCentral(int _puertoTCP, int _puertoUDP);
    ~ServidorCentral();

    void iniciar();
    void aceptarClientes(int cantidad);
    void atenderCliente(TipoSocket cliente);
    void recibirTelemetriaUDP(int cantidad);

    int getTramasValidas() const;
    int getTramasRechazadas() const;
    double promedioLecturas() const;
};

#endif
