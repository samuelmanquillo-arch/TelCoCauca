#include "RouterWiFi.h"
#include "Registro.h"
#include <thread>
#include <chrono>

RouterWiFi::RouterWiFi(const std::string& _id, int _canales, const std::string& _ip)
    : DispositivoComunicacion(_id, "Router WiFi 6", _ip), canalesActivos(_canales) {}

void RouterWiFi::transmitir() {
    registrarEventoSeguro(id + " transmitiendo en 5 GHz con " + std::to_string(canalesActivos) + " canales");
    std::this_thread::sleep_for(std::chrono::milliseconds(120));
}
