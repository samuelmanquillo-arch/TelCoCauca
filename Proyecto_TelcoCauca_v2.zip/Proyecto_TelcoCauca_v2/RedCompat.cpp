#include "RedCompat.h"

bool prepararRed() {
#ifdef _WIN32
    WSADATA datos;
    return WSAStartup(MAKEWORD(2, 2), &datos) == 0;
#else
    return true;
#endif
}

void liberarRed() {
#ifdef _WIN32
    WSACleanup();
#endif
}

void fijarTimeoutRecepcion(TipoSocket s, int milisegundos) {
#ifdef _WIN32
    DWORD tiempo = milisegundos;
    setsockopt(s, SOL_SOCKET, SO_RCVTIMEO, (const char*)&tiempo, sizeof(tiempo));
#else
    struct timeval tiempo;
    tiempo.tv_sec = milisegundos / 1000;
    tiempo.tv_usec = (milisegundos % 1000) * 1000;
    setsockopt(s, SOL_SOCKET, SO_RCVTIMEO, &tiempo, sizeof(tiempo));
#endif
}

bool hayClienteEsperando(TipoSocket s, int milisegundos) {
    fd_set conjunto;
    FD_ZERO(&conjunto);
    FD_SET(s, &conjunto);

    struct timeval tiempo;
    tiempo.tv_sec = milisegundos / 1000;
    tiempo.tv_usec = (milisegundos % 1000) * 1000;

    return select((int)s + 1, &conjunto, NULL, NULL, &tiempo) > 0;
}

bool enviarLinea(TipoSocket s, const std::string& texto) {
    std::string datos = texto + "\n";
    int enviados = send(s, datos.c_str(), (int)datos.size(), 0);
    return enviados == (int)datos.size();
}

bool leerLinea(TipoSocket s, std::string& linea) {
    linea.clear();
    char caracter;
    while (true) {
        int leidos = recv(s, &caracter, 1, 0);
        if (leidos <= 0) {
            return false;
        }
        if (caracter == '\n') {
            return true;
        }
        if (caracter != '\r') {
            linea += caracter;
        }
        if (linea.size() > 512) {
            return false;
        }
    }
}
