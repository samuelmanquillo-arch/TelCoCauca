#include "NodoRedInteligente.h"
#include "ExcepcionNodoRed.h"
#include <sstream>

static const double LECTURA_MINIMA = -40.0;
static const double LECTURA_MAXIMA = 120.0;

static bool ipValida(const std::string& ip) {
    if (ip.empty() || ip[ip.size() - 1] == '.') {
        return false;
    }
    std::istringstream entrada(ip);
    std::string parte;
    int octetos = 0;
    while (std::getline(entrada, parte, '.')) {
        if (parte.empty() || parte.size() > 3) {
            return false;
        }
        for (std::size_t i = 0; i < parte.size(); ++i) {
            if (parte[i] < '0' || parte[i] > '9') {
                return false;
            }
        }
        if (std::stoi(parte) > 255) {
            return false;
        }
        ++octetos;
    }
    return octetos == 4;
}

NodoRedInteligente::NodoRedInteligente(const std::string& _ip, const std::string& _mac, const std::string& _tipoSensor,
                                       double _valor, const std::string& _unidad, int _carga)
    : DispositivoRed(_ip, _mac, true), SensorIoT(_tipoSensor, _valor, _unidad), cargaProcesamiento(_carga) {
    if (!ipValida(_ip)) {
        throw ExcepcionNodoRed(101, "Direccion IP invalida: " + _ip);
    }
}

int NodoRedInteligente::getCargaProcesamiento() const { return cargaProcesamiento; }

void NodoRedInteligente::verificarLectura() const {
    if (!getEstadoOperativo()) {
        throw ExcepcionNodoRed(103, "El nodo " + getDireccionIP() + " esta inactivo.");
    }
    double valor = getValorLectura();
    if (valor < LECTURA_MINIMA || valor > LECTURA_MAXIMA) {
        std::ostringstream mensaje;
        mensaje << "Lectura fuera de rango en el nodo " << getDireccionIP() << ": " << valor
                << " " << getUnidad() << " (permitido " << LECTURA_MINIMA << " a " << LECTURA_MAXIMA << ")";
        throw ExcepcionNodoRed(102, mensaje.str());
    }
}

int NodoRedInteligente::operator+(const NodoRedInteligente& otro) const {
    return cargaProcesamiento + otro.cargaProcesamiento;
}

std::ostream& operator<<(std::ostream& os, const NodoRedInteligente& nodo) {
    os << "<NODO " << nodo.getDireccionIP() << " | " << nodo.getTipoSensor() << " = "
       << nodo.getValorLectura() << " " << nodo.getUnidad()
       << " | carga " << nodo.cargaProcesamiento << " | "
       << (nodo.getEstadoOperativo() ? "ACTIVO" : "INACTIVO") << ">";
    return os;
}
