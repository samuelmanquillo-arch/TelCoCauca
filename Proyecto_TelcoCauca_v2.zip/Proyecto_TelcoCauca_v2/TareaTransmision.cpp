#include "TareaTransmision.h"
#include "Registro.h"
#include <stdexcept>
#include <string>
#include <mutex>
#include <chrono>

void tareaTransmisionHilo(DispositivoComunicacion* dev, int& exitosas) {
    try {
        if (dev == nullptr) {
            throw std::invalid_argument("ERROR: Puntero nulo pasado al hilo.");
        }

        std::chrono::steady_clock::time_point inicio = std::chrono::steady_clock::now();
        dev->transmitir();
        std::chrono::steady_clock::time_point fin = std::chrono::steady_clock::now();
        long long milisegundos = std::chrono::duration_cast<std::chrono::milliseconds>(fin - inicio).count();

        registrarEventoSeguro("Transmision completada: " + dev->descripcion()
                              + " en " + std::to_string(milisegundos) + " ms");

        {
            std::lock_guard<std::mutex> lock(mtx_contador);
            ++exitosas;
        }
    }
    catch (const std::exception& e) {
        registrarEventoSeguro(std::string("EXCEPCION EN HILO: ") + e.what());
    }
}
