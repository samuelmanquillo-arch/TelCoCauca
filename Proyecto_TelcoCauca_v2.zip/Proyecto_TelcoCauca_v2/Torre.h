#ifndef TORRE_H
#define TORRE_H

#include <string>
#include <vector>

class Antena;

class Torre {
private:
    int idTorre;
    std::string ubicacion;
    double alturaMetros;
    std::vector<Antena*> listaAntenas;
public:
    Torre(int _idTorre, const std::string& _ubicacion, double _alturaMetros);

    int getIdTorre() const;
    std::string getUbicacion() const;
    double getAlturaMetros() const;

    void agregarAntena(Antena* antena);
    std::size_t cantidadAntenas() const;
    double frecuenciaPromedio() const;

    void mostrarInformacion() const;
};

#endif
