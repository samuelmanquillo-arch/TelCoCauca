#include "ExcepcionNodoRed.h"

ExcepcionNodoRed::ExcepcionNodoRed(int _codigo, const std::string& mensaje)
    : std::runtime_error(mensaje), codigo(_codigo) {}

int ExcepcionNodoRed::getCodigo() const { return codigo; }
