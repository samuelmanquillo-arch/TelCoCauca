#include "EstacionMonitoreo.h"
#include "ExcepcionNodoRed.h"
#include "Registro.h"
#include <stdexcept>
#include <mutex>

EstacionMonitoreo::EstacionMonitoreo(const std::string& _nombre) : nombre(_nombre) {}

void EstacionMonitoreo::revisarNodo(const NodoRedInteligente* nodo, int& nodosSanos, int& nodosConFalla) {
    try {
        if (nodo == nullptr) {
            throw std::invalid_argument("ERROR: Nodo nulo pasado a la estacion " + nombre);
        }

        nodo->verificarLectura();
        registrarEventoSeguro(nombre + ": nodo " + nodo->getDireccionIP() + " revisado, todo en orden");

        std::lock_guard<std::mutex> lock(mtx_contador);
        ++nodosSanos;
    }
    catch (const ExcepcionNodoRed& e) {
        registrarEventoSeguro(nombre + ": EXCEPCION NODO RED [" + std::to_string(e.getCodigo()) + "] " + e.what());
        std::lock_guard<std::mutex> lock(mtx_contador);
        ++nodosConFalla;
    }
    catch (const std::exception& e) {
        registrarEventoSeguro(std::string("EXCEPCION EN HILO: ") + e.what());
    }
}
