#include "ClienteNodo.h"
#include "RedCompat.h"
#include "ExcepcionNodoRed.h"
#include "Trama.h"
#include "Registro.h"
#include <cstring>
#include <mutex>

ClienteNodo::ClienteNodo(const std::string& _idNodo, const std::string& _tipoSensor, double _valorBase,
                         int _puertoTCP, int _puertoUDP, bool _sensorDanado)
    : idNodo(_idNodo), tipoSensor(_tipoSensor), valorBase(_valorBase),
      puertoTCP(_puertoTCP), puertoUDP(_puertoUDP), sensorDanado(_sensorDanado) {}

void ClienteNodo::ejecutar(int& completados) {
    TipoSocket socketTCP = SOCKET_INVALIDO;
    TipoSocket socketUDP = SOCKET_INVALIDO;
    try {
        sockaddr_in servidor;
        std::memset(&servidor, 0, sizeof(servidor));
        servidor.sin_family = AF_INET;
        servidor.sin_addr.s_addr = inet_addr("127.0.0.1");

        socketTCP = socket(AF_INET, SOCK_STREAM, 0);
        if (socketTCP == SOCKET_INVALIDO) {
            throw ExcepcionNodoRed(301, "No se pudo crear el socket TCP de " + idNodo);
        }
        fijarTimeoutRecepcion(socketTCP, 3000);
        servidor.sin_port = htons(puertoTCP);
        if (connect(socketTCP, (sockaddr*)&servidor, sizeof(servidor)) != 0) {
            throw ExcepcionNodoRed(301, "connect() fallo en " + idNodo);
        }

        std::string respuesta;
        enviarLinea(socketTCP, "HOLA " + idNodo);
        if (!leerLinea(socketTCP, respuesta)) {
            throw ExcepcionNodoRed(301, "El servidor no saludo a " + idNodo);
        }
        registrarEventoSeguro(idNodo + " recibio del servidor: " + respuesta);

        for (int i = 0; i < 3; ++i) {
            double lectura = valorBase + i * 0.5;
            if (sensorDanado && i == 2) {
                lectura = 500.0;
            }
            Trama trama(idNodo, tipoSensor, lectura);
            enviarLinea(socketTCP, trama.serializar());
            if (!leerLinea(socketTCP, respuesta)) {
                throw ExcepcionNodoRed(301, "Sin respuesta del servidor para " + idNodo);
            }
            registrarEventoSeguro(idNodo + " envio lectura " + std::to_string(i + 1) + " y el servidor dijo: " + respuesta);
        }

        socketUDP = socket(AF_INET, SOCK_DGRAM, 0);
        if (socketUDP == SOCKET_INVALIDO) {
            throw ExcepcionNodoRed(301, "No se pudo crear el socket UDP de " + idNodo);
        }
        servidor.sin_port = htons(puertoUDP);
        for (int i = 0; i < 2; ++i) {
            Trama telemetria(idNodo, tipoSensor, valorBase + 10 + i);
            std::string datos = telemetria.serializar();
            sendto(socketUDP, datos.c_str(), (int)datos.size(), 0, (sockaddr*)&servidor, sizeof(servidor));
        }
        registrarEventoSeguro(idNodo + " envio 2 datagramas UDP de telemetria");

        std::lock_guard<std::mutex> lock(mtx_contador);
        ++completados;
    }
    catch (const ExcepcionNodoRed& e) {
        registrarEventoSeguro("EXCEPCION DE RED EN CLIENTE [" + std::to_string(e.getCodigo()) + "] " + e.what());
    }
    catch (const std::exception& e) {
        registrarEventoSeguro(std::string("EXCEPCION EN HILO: ") + e.what());
    }

    if (socketTCP != SOCKET_INVALIDO) {
        CERRAR_SOCKET(socketTCP);
    }
    if (socketUDP != SOCKET_INVALIDO) {
        CERRAR_SOCKET(socketUDP);
    }
}
