#include "ServidorCentral.h"
#include "ExcepcionNodoRed.h"
#include "Registro.h"
#include <cstring>
#include <thread>
#include <mutex>

ServidorCentral::ServidorCentral(int _puertoTCP, int _puertoUDP)
    : puertoTCP(_puertoTCP), puertoUDP(_puertoUDP),
      socketTCP(SOCKET_INVALIDO), socketUDP(SOCKET_INVALIDO),
      tramasValidas(0), tramasRechazadas(0) {}

ServidorCentral::~ServidorCentral() {
    if (socketTCP != SOCKET_INVALIDO) {
        CERRAR_SOCKET(socketTCP);
    }
    if (socketUDP != SOCKET_INVALIDO) {
        CERRAR_SOCKET(socketUDP);
    }
}

void ServidorCentral::guardarLectura(const Trama& trama, const std::string& origen) {
    {
        std::lock_guard<std::mutex> lock(mtx_buffer);
        bufferLecturas.push_back(trama);
    }
    {
        std::lock_guard<std::mutex> lock(mtx_contador);
        ++tramasValidas;
    }
    registrarEventoSeguro("Servidor guardo lectura " + origen + ": " + trama.descripcion());
}

void ServidorCentral::iniciar() {
    sockaddr_in direccion;
    std::memset(&direccion, 0, sizeof(direccion));
    direccion.sin_family = AF_INET;
    direccion.sin_addr.s_addr = inet_addr("127.0.0.1");
    int opcion = 1;

    socketTCP = socket(AF_INET, SOCK_STREAM, 0);
    if (socketTCP == SOCKET_INVALIDO) {
        throw ExcepcionNodoRed(301, "No se pudo crear el socket TCP del servidor.");
    }
    setsockopt(socketTCP, SOL_SOCKET, SO_REUSEADDR, (const char*)&opcion, sizeof(opcion));
    direccion.sin_port = htons(puertoTCP);
    if (bind(socketTCP, (sockaddr*)&direccion, sizeof(direccion)) != 0) {
        throw ExcepcionNodoRed(301, "bind() fallo en el puerto TCP " + std::to_string(puertoTCP));
    }
    if (listen(socketTCP, 8) != 0) {
        throw ExcepcionNodoRed(301, "listen() fallo en el puerto TCP " + std::to_string(puertoTCP));
    }
    registrarEventoSeguro("Servidor Central escuchando TCP en el puerto " + std::to_string(puertoTCP));

    socketUDP = socket(AF_INET, SOCK_DGRAM, 0);
    if (socketUDP == SOCKET_INVALIDO) {
        throw ExcepcionNodoRed(301, "No se pudo crear el socket UDP del servidor.");
    }
    direccion.sin_port = htons(puertoUDP);
    if (bind(socketUDP, (sockaddr*)&direccion, sizeof(direccion)) != 0) {
        throw ExcepcionNodoRed(301, "bind() fallo en el puerto UDP " + std::to_string(puertoUDP));
    }
    fijarTimeoutRecepcion(socketUDP, 3000);
    registrarEventoSeguro("Servidor Central recibiendo telemetria UDP en el puerto " + std::to_string(puertoUDP));
}

void ServidorCentral::aceptarClientes(int cantidad) {
    std::vector<std::thread> hilosClientes;
    try {
        for (int i = 0; i < cantidad; ++i) {
            if (!hayClienteEsperando(socketTCP, 5000)) {
                registrarEventoSeguro("Servidor: nadie mas se conecto, se deja de esperar clientes.");
                break;
            }
            TipoSocket cliente = accept(socketTCP, NULL, NULL);
            if (cliente == SOCKET_INVALIDO) {
                throw ExcepcionNodoRed(301, "accept() fallo en el servidor.");
            }
            hilosClientes.push_back(std::thread(&ServidorCentral::atenderCliente, this, cliente));
        }
    }
    catch (const ExcepcionNodoRed& e) {
        registrarEventoSeguro("EXCEPCION EN SERVIDOR [" + std::to_string(e.getCodigo()) + "] " + e.what());
    }
    catch (const std::exception& e) {
        registrarEventoSeguro(std::string("EXCEPCION EN HILO: ") + e.what());
    }

    for (std::size_t i = 0; i < hilosClientes.size(); ++i) {
        if (hilosClientes[i].joinable()) {
            hilosClientes[i].join();
        }
    }
}

void ServidorCentral::atenderCliente(TipoSocket cliente) {
    fijarTimeoutRecepcion(cliente, 3000);
    std::string linea;
    try {
        if (!leerLinea(cliente, linea) || linea.substr(0, 5) != "HOLA ") {
            throw ExcepcionNodoRed(301, "El cliente no envio un saludo valido.");
        }
        std::string idCliente = linea.substr(5);
        enviarLinea(cliente, "BIENVENIDO " + idCliente);
        registrarEventoSeguro("Servidor: " + idCliente + " se conecto por TCP");

        while (leerLinea(cliente, linea)) {
            try {
                Trama trama = Trama::deserializar(linea);
                guardarLectura(trama, "TCP");
                enviarLinea(cliente, "OK");
            }
            catch (const ExcepcionNodoRed& e) {
                {
                    std::lock_guard<std::mutex> lock(mtx_contador);
                    ++tramasRechazadas;
                }
                registrarEventoSeguro("EXCEPCION EN SERVIDOR [" + std::to_string(e.getCodigo()) + "] " + e.what());
                enviarLinea(cliente, "ERROR " + std::to_string(e.getCodigo()));
            }
        }
    }
    catch (const ExcepcionNodoRed& e) {
        registrarEventoSeguro("EXCEPCION EN SERVIDOR [" + std::to_string(e.getCodigo()) + "] " + e.what());
    }
    catch (const std::exception& e) {
        registrarEventoSeguro(std::string("EXCEPCION EN HILO: ") + e.what());
    }
    CERRAR_SOCKET(cliente);
}

void ServidorCentral::recibirTelemetriaUDP(int cantidad) {
    for (int i = 0; i < cantidad; ++i) {
        char buffer[256];
        sockaddr_in origen;
        LongitudDireccion tamanio = sizeof(origen);
        int bytes = recvfrom(socketUDP, buffer, sizeof(buffer) - 1, 0, (sockaddr*)&origen, &tamanio);
        if (bytes <= 0) {
            registrarEventoSeguro("Servidor: se acabo el tiempo de espera de telemetria UDP.");
            break;
        }
        buffer[bytes] = '\0';
        try {
            Trama trama = Trama::deserializar(std::string(buffer));
            guardarLectura(trama, "UDP");
        }
        catch (const ExcepcionNodoRed& e) {
            {
                std::lock_guard<std::mutex> lock(mtx_contador);
                ++tramasRechazadas;
            }
            registrarEventoSeguro("EXCEPCION EN SERVIDOR [" + std::to_string(e.getCodigo()) + "] " + e.what());
        }
    }
}

int ServidorCentral::getTramasValidas() const { return tramasValidas; }
int ServidorCentral::getTramasRechazadas() const { return tramasRechazadas; }

double ServidorCentral::promedioLecturas() const {
    if (bufferLecturas.empty()) {
        return 0.0;
    }
    double suma = 0.0;
    for (std::size_t i = 0; i < bufferLecturas.size(); ++i) {
        suma += bufferLecturas[i].getValor();
    }
    return suma / bufferLecturas.size();
}
