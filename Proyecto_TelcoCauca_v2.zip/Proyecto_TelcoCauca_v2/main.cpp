#include <iostream>
#include <vector>
#include <string>
#include <stdexcept>
#include <thread>
#include <functional>

#include "Tecnico.h"
#include "Antena.h"
#include "Torre.h"
#include "ExcepcionNodoRed.h"
#include "NodoRedInteligente.h"
#include "DispositivoComunicacion.h"
#include "RouterWiFi.h"
#include "GatewayLoRa.h"
#include "SwitchFibra.h"
#include "TareaTransmision.h"
#include "EstacionMonitoreo.h"
#include "EventoIngenieria2027.h"
#include "Registro.h"
#include "RedCompat.h"
#include "ServidorCentral.h"
#include "ClienteNodo.h"

static void moduloInfraestructura() {
    std::cout << std::endl << ">>> MODULO 1 - Infraestructura fisica" << std::endl;
    Tecnico camila(1, "Camila Ortiz", "Fibra optica");
    Tecnico julian(2, "Julian Pardo", "Radiofrecuencia");
    Antena antena1(201, 2600.0, "4G", &camila);
    Antena antena2(202, 3500.0, "5G", &julian);
    Antena antena3(203, 700.0, "4G", nullptr);
    Torre torre(7, "Popayan Norte", 42.5);
    torre.agregarAntena(&antena1);
    torre.agregarAntena(&antena2);
    torre.agregarAntena(&antena3);

    camila.mostrarInformacion();
    julian.mostrarInformacion();
    torre.mostrarInformacion();
}

static void moduloNodos() {
    std::cout << std::endl << ">>> MODULO 2 - Nodos inteligentes y excepciones" << std::endl;
    try {
        NodoRedInteligente nodoA("10.20.1.11", "02:AA:00:00:00:11", "Temperatura", 24.8, "C", 55);
        NodoRedInteligente nodoB("10.20.1.12", "02:AA:00:00:00:12", "Humedad", 71.0, "%", 30);
        std::cout << nodoA << std::endl;
        std::cout << nodoB << std::endl;
        int cargaTotal = nodoA + nodoB;
        std::cout << "Carga de procesamiento combinada: " << cargaTotal << std::endl;

        NodoRedInteligente nodoMalo("10.20.1.999", "02:AA:00:00:00:13", "Voltaje", 12.0, "V", 10);
        std::cout << nodoMalo << std::endl;
    }
    catch (const ExcepcionNodoRed& e) {
        std::cout << "EXCEPCION NODO RED [" << e.getCodigo() << "]: " << e.what() << std::endl;
    }

    try {
        NodoRedInteligente nodoCaliente("10.20.1.14", "02:AA:00:00:00:14", "Temperatura", 150.0, "C", 20);
        std::cout << nodoCaliente << std::endl;
        nodoCaliente.verificarLectura();
    }
    catch (const ExcepcionNodoRed& e) {
        std::cout << "EXCEPCION NODO RED [" << e.getCodigo() << "]: " << e.what() << std::endl;
    }
}

static void moduloDispositivos(const std::vector<DispositivoComunicacion*>& red) {
    std::cout << std::endl << ">>> MODULO 3 - Dispositivos polimorficos" << std::endl;
    for (std::size_t i = 0; i < red.size(); ++i) {
        try {
            if (red[i] == nullptr) {
                throw std::invalid_argument("ERROR: Hay un puntero nulo en la posicion " + std::to_string(i) + " del vector.");
            }
            std::cout << red[i]->descripcion() << "  ->  " << red[i]->serializar() << std::endl;
        }
        catch (const std::invalid_argument& e) {
            std::cout << "EXCEPCION: " << e.what() << std::endl;
        }
    }
}

static void moduloConcurrencia(const std::vector<DispositivoComunicacion*>& red) {
    std::cout << std::endl << ">>> MODULO 4 - Hilos y exclusion mutua" << std::endl;
    int transmisionesExitosas = 0;
    int nodosSanos = 0;
    int nodosConFalla = 0;
    EstacionMonitoreo estacion("Estacion Popayan Norte");

    std::vector<NodoRedInteligente> nodos;
    nodos.push_back(NodoRedInteligente("10.20.1.11", "02:AA:00:00:00:11", "Temperatura", 24.8, "C", 55));
    nodos.push_back(NodoRedInteligente("10.20.1.12", "02:AA:00:00:00:12", "Humedad", 71.0, "%", 30));
    nodos.push_back(NodoRedInteligente("10.20.1.14", "02:AA:00:00:00:14", "Temperatura", 150.0, "C", 20));
    nodos.push_back(NodoRedInteligente("10.20.1.15", "02:AA:00:00:00:15", "Presion", 60.0, "kPa", 25));
    nodos[3].setEstadoOperativo(false);

    std::vector<EventoIngenieria2027> agenda;
    agenda.push_back(EventoIngenieria2027("MWC Barcelona 2027", "1 al 4 de marzo de 2027", "Barcelona, Espana", "Feria mundial de telecomunicaciones moviles y 5G"));
    agenda.push_back(EventoIngenieria2027("IEEE World Forum on Internet of Things 2027", "2027 (fecha por confirmar)", "Calgary, Canada", "Foro IEEE sobre IoT y redes de sensores"));
    agenda.push_back(EventoIngenieria2027("ANDICOM 2027", "Septiembre de 2027 (por confirmar)", "Cartagena, Colombia", "Congreso internacional de las TIC"));

    std::vector<std::thread> hilos;
    for (std::size_t i = 0; i < red.size(); ++i) {
        hilos.push_back(std::thread(tareaTransmisionHilo, red[i], std::ref(transmisionesExitosas)));
    }
    for (std::size_t i = 0; i < nodos.size(); ++i) {
        hilos.push_back(std::thread(&EstacionMonitoreo::revisarNodo, &estacion, &nodos[i],
                                    std::ref(nodosSanos), std::ref(nodosConFalla)));
    }
    hilos.push_back(std::thread(mostrarAgendaEventos2027, std::cref(agenda)));

    for (std::size_t i = 0; i < hilos.size(); ++i) {
        if (hilos[i].joinable()) {
            hilos[i].join();
        }
    }

    registrarEventoSeguro("Resumen -> transmisiones exitosas: " + std::to_string(transmisionesExitosas));
    registrarEventoSeguro("Resumen -> nodos sanos: " + std::to_string(nodosSanos)
                          + ", nodos con falla: " + std::to_string(nodosConFalla));
}

static void moduloRed() {
    std::cout << std::endl << ">>> MODULO 5 - Red cliente-servidor (TCP y UDP)" << std::endl;
    if (!prepararRed()) {
        std::cout << "No se pudo preparar la capa de red." << std::endl;
        return;
    }

    ServidorCentral servidor(6000, 6001);
    try {
        servidor.iniciar();

        int clientesCompletos = 0;
        std::vector<ClienteNodo> clientes;
        clientes.push_back(ClienteNodo("NODO-A", "Temperatura", 24.8, 6000, 6001, false));
        clientes.push_back(ClienteNodo("NODO-B", "Humedad", 71.0, 6000, 6001, false));
        clientes.push_back(ClienteNodo("NODO-C", "Voltaje", 12.0, 6000, 6001, true));
        clientes.push_back(ClienteNodo("NODO-D", "Presion", 60.0, 6000, 6001, false));

        std::thread hiloAceptador(&ServidorCentral::aceptarClientes, &servidor, 4);
        std::thread hiloUDP(&ServidorCentral::recibirTelemetriaUDP, &servidor, 8);

        std::vector<std::thread> hilosClientes;
        for (std::size_t i = 0; i < clientes.size(); ++i) {
            hilosClientes.push_back(std::thread(&ClienteNodo::ejecutar, &clientes[i], std::ref(clientesCompletos)));
        }
        for (std::size_t i = 0; i < hilosClientes.size(); ++i) {
            if (hilosClientes[i].joinable()) {
                hilosClientes[i].join();
            }
        }
        hiloAceptador.join();
        hiloUDP.join();

        registrarEventoSeguro("Resumen -> clientes que completaron su envio: " + std::to_string(clientesCompletos));
        registrarEventoSeguro("Resumen -> tramas validas: " + std::to_string(servidor.getTramasValidas())
                              + ", rechazadas: " + std::to_string(servidor.getTramasRechazadas()));
        registrarEventoSeguro("Resumen -> promedio de lecturas guardadas: " + std::to_string(servidor.promedioLecturas()));
    }
    catch (const ExcepcionNodoRed& e) {
        registrarEventoSeguro("EXCEPCION DE RED [" + std::to_string(e.getCodigo()) + "] " + e.what());
    }
    liberarRed();
}

int main() {
    std::vector<DispositivoComunicacion*> red;
    red.push_back(new RouterWiFi("RT-PPN-01", 8, "10.20.0.1"));
    red.push_back(new GatewayLoRa("GW-LORA-02", 915.2f, "10.20.0.2"));
    red.push_back(new SwitchFibra("SW-FIB-03", 16, "10.20.0.3"));
    red.push_back(nullptr);

    moduloInfraestructura();
    moduloNodos();
    moduloDispositivos(red);
    moduloConcurrencia(red);
    moduloRed();

    for (std::size_t i = 0; i < red.size(); ++i) {
        delete red[i];
    }
    red.clear();

    std::cout << std::endl << "Sistema finalizado correctamente." << std::endl;
    return 0;
}
