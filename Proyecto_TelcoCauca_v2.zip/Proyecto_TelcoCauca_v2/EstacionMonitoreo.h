#ifndef ESTACIONMONITOREO_H
#define ESTACIONMONITOREO_H

#include <string>
#include "NodoRedInteligente.h"

class EstacionMonitoreo {
private:
    std::string nombre;
public:
    explicit EstacionMonitoreo(const std::string& _nombre);

    void revisarNodo(const NodoRedInteligente* nodo, int& nodosSanos, int& nodosConFalla);
};

#endif
