#ifndef ITRANSMISIBLE_H
#define ITRANSMISIBLE_H

#include <string>

class ITransmisible {
public:
    virtual ~ITransmisible() {}
    virtual std::string serializar() const = 0;
    virtual std::string descripcion() const = 0;
};

#endif
