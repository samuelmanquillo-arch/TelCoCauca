#ifndef TECNICO_H
#define TECNICO_H

#include <string>

class Tecnico {
private:
    int idTecnico;
    std::string nombre;
    std::string especialidad;
public:
    Tecnico(int _idTecnico, const std::string& _nombre, const std::string& _especialidad);

    int getIdTecnico() const;
    std::string getNombre() const;
    std::string getEspecialidad() const;

    void setNombre(const std::string& _nombre);
    void setEspecialidad(const std::string& _especialidad);

    std::string descripcionCorta() const;
    void mostrarInformacion() const;
};

#endif
