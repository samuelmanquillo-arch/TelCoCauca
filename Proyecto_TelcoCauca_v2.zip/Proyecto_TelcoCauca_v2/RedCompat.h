#ifndef REDCOMPAT_H
#define REDCOMPAT_H

#include <string>

#ifdef _WIN32
#include <winsock2.h>
typedef SOCKET TipoSocket;
typedef int LongitudDireccion;
#define SOCKET_INVALIDO INVALID_SOCKET
#define CERRAR_SOCKET closesocket
#else
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
typedef int TipoSocket;
typedef socklen_t LongitudDireccion;
#define SOCKET_INVALIDO (-1)
#define CERRAR_SOCKET close
#endif

bool prepararRed();
void liberarRed();
void fijarTimeoutRecepcion(TipoSocket s, int milisegundos);
bool hayClienteEsperando(TipoSocket s, int milisegundos);
bool enviarLinea(TipoSocket s, const std::string& texto);
bool leerLinea(TipoSocket s, std::string& linea);

#endif
