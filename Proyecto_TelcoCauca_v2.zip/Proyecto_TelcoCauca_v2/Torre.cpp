#include "Torre.h"
#include "Antena.h"
#include <iostream>
#include <stdexcept>

Torre::Torre(int _idTorre, const std::string& _ubicacion, double _alturaMetros)
    : idTorre(_idTorre), ubicacion(_ubicacion), alturaMetros(_alturaMetros) {}

int Torre::getIdTorre() const { return idTorre; }
std::string Torre::getUbicacion() const { return ubicacion; }
double Torre::getAlturaMetros() const { return alturaMetros; }

void Torre::agregarAntena(Antena* antena) {
    if (antena == nullptr) {
        throw std::invalid_argument("ERROR: No se puede agregar una antena nula a la torre.");
    }
    listaAntenas.push_back(antena);
}

std::size_t Torre::cantidadAntenas() const { return listaAntenas.size(); }

double Torre::frecuenciaPromedio() const {
    if (listaAntenas.empty()) {
        return 0.0;
    }
    double suma = 0.0;
    for (std::size_t i = 0; i < listaAntenas.size(); ++i) {
        suma += listaAntenas[i]->getFrecuenciaMHz();
    }
    return suma / listaAntenas.size();
}

void Torre::mostrarInformacion() const {
    std::cout << "TORRE #" << idTorre << " | " << ubicacion << " | " << alturaMetros
              << " m | " << listaAntenas.size() << " antena(s)" << std::endl;
    for (std::size_t i = 0; i < listaAntenas.size(); ++i) {
        std::cout << "    - " << listaAntenas[i]->resumen() << std::endl;
    }
    std::cout << "    Frecuencia promedio: " << frecuenciaPromedio() << " MHz" << std::endl;
}
