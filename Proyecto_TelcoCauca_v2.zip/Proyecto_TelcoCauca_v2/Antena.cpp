#include "Antena.h"
#include <iostream>
#include <sstream>

Antena::Antena(int _idAntena, double _frecuenciaMHz, const std::string& _tecnologia, Tecnico* _responsable)
    : idAntena(_idAntena), frecuenciaMHz(_frecuenciaMHz), tecnologia(_tecnologia),
      responsableMantenimiento(_responsable) {}

int Antena::getIdAntena() const { return idAntena; }
double Antena::getFrecuenciaMHz() const { return frecuenciaMHz; }
std::string Antena::getTecnologia() const { return tecnologia; }
Tecnico* Antena::getResponsable() const { return responsableMantenimiento; }

void Antena::setResponsable(Tecnico* _responsable) { responsableMantenimiento = _responsable; }

std::string Antena::resumen() const {
    std::ostringstream salida;
    salida << "ANTENA #" << idAntena << " | " << frecuenciaMHz << " MHz | " << tecnologia << " | Resp: ";
    if (responsableMantenimiento != nullptr) {
        salida << responsableMantenimiento->descripcionCorta();
    } else {
        salida << "Sin asignar";
    }
    return salida.str();
}

void Antena::mostrarInformacion() const {
    std::cout << resumen() << std::endl;
}
