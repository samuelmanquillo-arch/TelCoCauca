#include "Registro.h"
#include <iostream>
#include <iomanip>
#include <thread>

std::mutex mtx_consola;
std::mutex mtx_contador;
std::mutex mtx_buffer;

static int numeroLinea = 0;

void registrarEventoSeguro(const std::string& mensaje) {
    std::lock_guard<std::mutex> lock(mtx_consola);
    ++numeroLinea;
    std::cout << "[#" << std::setfill('0') << std::setw(3) << numeroLinea << std::setfill(' ')
              << "][HILO " << std::this_thread::get_id() << "] " << mensaje << std::endl;
}
