#include "GatewayLoRa.h"
#include "Registro.h"
#include <thread>
#include <chrono>
#include <sstream>

GatewayLoRa::GatewayLoRa(const std::string& _id, float _freq, const std::string& _ip)
    : DispositivoComunicacion(_id, "Gateway LoRaWAN", _ip), frecuenciaMHz(_freq) {}

void GatewayLoRa::transmitir() {
    std::ostringstream mensaje;
    mensaje << id << " enviando paquete LoRa a " << frecuenciaMHz << " MHz";
    registrarEventoSeguro(mensaje.str());
    std::this_thread::sleep_for(std::chrono::milliseconds(250));
}
